package com.autoclan.donator

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.*
import kotlin.math.abs
import kotlin.random.Random

/**
 * v2: self-calibrating (finds the donate buttons and the popup by color, no fixed phone coordinates),
 * array-based pixel access (fast), ON/OFF indicator and a debug line in the overlay.
 */
class DonatorService : AccessibilityService() {

    // ---- CONFIG ----
    private val COLS = floatArrayOf(611f, 698f, 786f, 873f, 960f, 1047f, 1135f) // reference card centers
    private val FULL_GRID_MIN = 9      // >= this many colored troop cards => empty request
    private val SPELL_PROB = 0.5f      // chance to also give a spell on empty requests
    private val SCALE = 2             // screenshots are shrunk 2x: 4x less memory and CPU (important on Galaxy A11)
    private var speed = 5              // 1 (slow) .. 5 (fastest)
    private val IDLE = longArrayOf(200, 120, 60, 30, 0)
    private val SETTLE = longArrayOf(250, 180, 120, 60, 0)
    private val HOLDC = longArrayOf(900, 800, 700, 550, 400)
    private val HOLDE = longArrayOf(1500, 1300, 1200, 1000, 800)
    private fun lv(a: LongArray) = a[speed - 1]
    private val RETRY = longArrayOf(3000, 2000, 1200, 700, 400) // retry a still-open request (half-filled) after this many ms
    private val NOTHING_MS = 6000L // nothing could be donated -> leave this request alone for a while
    // ----------------

    private class Frame(val w: Int, val h: Int, val px: IntArray, val k: Int)
    private class Geo(val x0: Int, val x1: Int, val s: Float, val lb: Int)

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val ui = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private var overlay: View? = null
    private var startBtn: Button? = null
    private var stopBtn: Button? = null
    private var stateTv: TextView? = null
    private var dbgTv: TextView? = null
    private var speedTv: TextView? = null
    private fun showSpeed() { speedTv?.text = "speed $speed/5" }
    private val skip = ArrayList<Pair<Float, Long>>()

    companion object { @Volatile var instance: DonatorService? = null }

    private fun prefs() = getSharedPreferences("donator", MODE_PRIVATE)
    override fun onServiceConnected() {
        instance = this; addOverlay(); render(false)
        if (prefs().getBoolean("run", false)) start()   // restarted by the system: continue until the user presses STOP
    }
    fun showPanel() { ui.post { overlay?.visibility = View.VISIBLE } }
    fun hidePanel() { userStop(); ui.post { overlay?.visibility = View.GONE } }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stop() }
    override fun onDestroy() {
        instance = null
        stop()
        overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        super.onDestroy()
    }

    // ---------- overlay ----------
    private fun addOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.argb(160, 0, 0, 0)) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startBtn = Button(this).apply { text = "START"; setOnClickListener { userStart() } }
        stopBtn = Button(this).apply { text = "STOP"; setOnClickListener { userStop() } }
        val closeBtn = Button(this).apply { text = "✕"; setOnClickListener { hidePanel() } }
        row.addView(startBtn); row.addView(stopBtn); row.addView(closeBtn)
        stateTv = TextView(this).apply { textSize = 16f; setPadding(12, 4, 12, 0) }
        dbgTv = TextView(this).apply { textSize = 11f; setTextColor(Color.WHITE); setPadding(12, 0, 12, 4) }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val minus = Button(this).apply { text = "−" }
        val plus = Button(this).apply { text = "+" }
        speedTv = TextView(this).apply { textSize = 16f; setTextColor(Color.WHITE); setPadding(20, 0, 20, 0); gravity = Gravity.CENTER }
        minus.setOnClickListener { speed = maxOf(1, speed - 1); showSpeed() }
        plus.setOnClickListener { speed = minOf(5, speed + 1); showSpeed() }
        row2.addView(minus); row2.addView(speedTv); row2.addView(plus)
        showSpeed()
        col.addView(row); col.addView(row2); col.addView(stateTv); col.addView(dbgTv)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; y = 40 }
        wm.addView(col, lp); overlay = col
    }

    private fun render(on: Boolean) = ui.post {
        startBtn?.setBackgroundColor(if (on) Color.rgb(46, 160, 67) else Color.LTGRAY)
        stopBtn?.setBackgroundColor(if (on) Color.LTGRAY else Color.rgb(220, 50, 47))
        stateTv?.text = if (on) "● ON" else "● OFF"
        stateTv?.setTextColor(if (on) Color.rgb(80, 255, 100) else Color.rgb(255, 90, 90))
    }
    private fun dbg(t: String) { ui.post { dbgTv?.text = t } }

    private fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            while (isActive) {
                try { loop() }
                catch (e: CancellationException) { throw e }
                catch (e: Throwable) { dbg("error ${e.javaClass.simpleName}, restarting"); delay(300) }
            }
        }
        render(true)
    }
    private fun stop() { job?.cancel(); job = null; render(false) }
    private fun userStart() { prefs().edit().putBoolean("run", true).apply(); start() }
    private fun userStop() { prefs().edit().putBoolean("run", false).apply(); stop() }

    // ---------- main loop ----------
    private suspend fun loop() {
        run {
            while (currentCoroutineContext().isActive) {
                val f = shot()
                if (f == null) { dbg("no screenshot"); delay(100); continue }
                val geo = popupGeo(f)
                if (geo != null) { dbg("stray popup: closing"); closePopup(f, geo); delay(150); continue }
                val now = System.currentTimeMillis()
                val btns = greenButtons(f).filter { b -> skip.none { abs(it.first - b.second) < 0.04f * f.h && now < it.second } }
                dbg("buttons=${btns.size}  screen=${f.w}x${f.h}")
                if (btns.isEmpty()) { delay(lv(IDLE)); continue }
                val b = btns.maxByOrNull { it.second }!!
                press(b.first.toFloat() * f.k, b.second.toFloat() * f.k, 40)
                val donated = handlePopup()
                val t = System.currentTimeMillis()
                skip.add(b.second.toFloat() to (t + if (donated) lv(RETRY) else NOTHING_MS))
                skip.removeAll { t > it.second }
                delay(lv(IDLE) / 2)
            }
        }
    }

    /** @return true if at least one card was pressed. */
    private suspend fun handlePopup(): Boolean {
        var f: Frame? = null; var geo: Geo? = null
        val t0 = System.currentTimeMillis()
        while (System.currentTimeMillis() - t0 < 1500) {
            val fr = shot()
            val g = fr?.let { popupGeo(it) }
            if (fr != null && g != null) { f = fr; geo = g; break }
            delay(40)
        }
        if (f == null || geo == null) { dbg("popup not found"); return false }
        if (speed < 4) {
            delay(lv(SETTLE))
            val fr2 = shot(); val g2 = fr2?.let { popupGeo(it) }
            if (fr2 != null && g2 != null) { f = fr2; geo = g2 }
        }
        val frame: Frame = f; val gg: Geo = geo
        val s = gg.s
        val r1 = gg.lb - 453f * s; val r2 = gg.lb - 343f * s; val rs = gg.lb - 187f * s
        val half = (30f * s).toInt()
        fun cx(i: Int) = gg.x0 + (COLS[i] - 565f) * s
        val troops = ArrayList<Pair<Float, Float>>(); val spells = ArrayList<Pair<Float, Float>>()
        for (i in COLS.indices) if (colored(frame, cx(i), r1, half)) troops.add(cx(i) to r1)
        for (i in COLS.indices) if (colored(frame, cx(i), r2, half)) troops.add(cx(i) to r2)
        for (i in COLS.indices) if (colored(frame, cx(i), rs, half)) spells.add(cx(i) to rs)
        dbg("popup ok  troops=${troops.size} spells=${spells.size}")
        suspend fun tap(x: Float, y: Float, ms: Long) = press(x * frame.k, y * frame.k, ms)
        if (troops.size >= FULL_GRID_MIN) {
            tap(cx(0), r1, lv(HOLDE))
            if (spells.isNotEmpty() && Random.nextFloat() < SPELL_PROB) tap(spells[0].first, spells[0].second, lv(HOLDC))
        } else {
            // all requested troops, but ONLY the first colored spell (pressing the other spells wastes time)
            for (p in troops + spells.take(1)) { tap(p.first, p.second, lv(HOLDC)); delay(Random.nextLong(20, 50)) }
        }
        closePopup(frame, gg)
        delay(lv(SETTLE) / 2)
        return troops.isNotEmpty() || spells.isNotEmpty()
    }

    private suspend fun closePopup(f: Frame, geo: Geo) {
        press(minOf(f.w - 1f, geo.x1 + 0.2f * f.h) * f.k, 0.5f * f.h * f.k, 30)
    }

    // ---------- vision (array based) ----------
    private fun colored(f: Frame, cx: Float, cy: Float, half: Int): Boolean {
        var c = 0; var t = 0
        val y0 = (cy - half).toInt().coerceAtLeast(0); val y1 = (cy + half).toInt().coerceAtMost(f.h - 1)
        val x0 = (cx - half).toInt().coerceAtLeast(0); val x1 = (cx + half).toInt().coerceAtMost(f.w - 1)
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val p = f.px[y * f.w + x]
                val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
                val mx = maxOf(r, g, b); val mn = minOf(r, g, b)
                if (mx > 76 && (mx - mn) * 4 > mx) c++
                t++; x += 3
            }
            y += 3
        }
        return t > 0 && c.toFloat() / t > 0.12f
    }

    private fun beige(p: Int) =
        abs(((p shr 16) and 255) - 216) < 10 && abs(((p shr 8) and 255) - 215) < 10 && abs((p and 255) - 206) < 10

    /** Finds the beige donate popup; calibrates scale from its width. null if no popup. */
    private fun popupGeo(f: Frame): Geo? {
        val H = f.h
        var x0 = -1; var x1 = -1
        var x = (0.55f * H).toInt(); val xe = minOf(f.w - 1, (1.6f * H).toInt())
        while (x < xe) {
            var c = 0; var y = 0
            while (y < H) { if (beige(f.px[y * f.w + x])) c += 2; y += 2 }
            if (c >= 0.30f * H) { if (x0 < 0) x0 = x; x1 = x }
            x += 2
        }
        if (x0 < 0 || x1 - x0 < 0.6f * H) return null
        val sc = (x1 - x0) / 616f
        val col = x0 + (12f * sc).toInt()      // a column well inside the panel: the bottom row there is stable
        var lb = -1
        var y = H - 1
        while (y >= 0) { if (beige(f.px[y * f.w + col])) { lb = y; break }; y-- }
        if (lb < 0) return null
        return Geo(x0, x1, sc, lb)
    }

    /** Green donate buttons in the chat column: list of (centerX, centerY) in pixels. */
    private fun greenButtons(f: Frame): List<Pair<Int, Int>> {
        val H = f.h; val out = ArrayList<Pair<Int, Int>>()
        val xMax = (H * 0.64f).toInt().coerceAtMost(f.w); val yMax = (H * 0.88f).toInt()
        var st = -1; var minx = Int.MAX_VALUE; var maxx = -1
        var y = 0
        while (y <= yMax) {
            var cnt = 0; var rmin = Int.MAX_VALUE; var rmax = -1
            val base = y * f.w
            var x = 0
            while (x < xMax) {
                val p = f.px[base + x]
                val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
                val mx = maxOf(r, g, b); val d = mx - minOf(r, g, b)
                if (g == mx && d > 0 && mx >= 140 && d * 10 > 4 * mx) {
                    val h = 60f * (b - r) / d + 120f
                    if (h > 70f && h < 110f) { cnt += 2; if (x < rmin) rmin = x; if (x > rmax) rmax = x }
                }
                x += 2
            }
            if (cnt >= 0.05f * H) {
                if (st < 0) { st = y; minx = Int.MAX_VALUE; maxx = -1 }
                minx = minOf(minx, rmin); maxx = maxOf(maxx, rmax)
            } else if (st >= 0) {
                val hh = y - st; val ww = maxx - minx
                if (hh >= (0.03f * H).toInt() && hh <= (0.09f * H).toInt() &&
                    ww >= (0.08f * H).toInt() && ww <= (0.22f * H).toInt() && (minx + maxx) / 2 >= 0.42f * H
                ) out.add(((minx + maxx) / 2) to ((st + y) / 2))
                st = -1
            }
            y += 2
        }
        return out
    }

    // ---------- device ----------
    private suspend fun shot(): Frame? = suspendCancellableCoroutine { c ->
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                var out: Frame? = null
                try {
                    val hb = r.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                    val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (soft != null) {
                        val sw = maxOf(1, soft.width / SCALE); val sh = maxOf(1, soft.height / SCALE)
                        val small = Bitmap.createScaledBitmap(soft, sw, sh, false)
                        val px = IntArray(sw * sh)
                        small.getPixels(px, 0, sw, 0, 0, sw, sh)
                        if (small !== soft) small.recycle()
                        soft.recycle()
                        out = Frame(sw, sh, px, SCALE)
                    }
                } catch (t: Throwable) { out = null }   // never let a callback crash the service
                if (c.isActive) c.resume(out) { }
            }
            override fun onFailure(code: Int) { if (c.isActive) c.resume(null) { } }
        })
    }

    private suspend fun press(x: Float, y: Float, ms: Long) = suspendCancellableCoroutine<Unit> { c ->
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, ms)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (c.isActive) c.resume(Unit) { } }
            override fun onCancelled(d: GestureDescription?) { if (c.isActive) c.resume(Unit) { } }
        }, null)
        if (!ok && c.isActive) c.resume(Unit) { }
    }
}
