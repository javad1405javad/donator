package com.autoclan.donator

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        l.addView(TextView(this).apply {
            text = "1) Open Accessibility settings and enable \"Auto Clan Donator\".\n" +
                "2) Open Clash of Clans, then the clan chat.\n" +
                "3) Press START on the small floating panel (top right). STOP to halt."
            textSize = 16f
        })
        l.addView(Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        l.addView(Button(this).apply {
            text = "Show START/STOP panel"
            setOnClickListener { DonatorService.instance?.showPanel() }
        })
        l.addView(Button(this).apply {
            text = "Hide panel (✕ also works)"
            setOnClickListener { DonatorService.instance?.hidePanel() }
        })
        setContentView(l)
    }
}
