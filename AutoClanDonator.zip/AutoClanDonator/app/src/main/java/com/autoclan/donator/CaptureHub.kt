package com.autoclan.donator

/** One screen frame from the fast capture (already shrunk): ARGB ints, w*h. */
class RawFrame(val w: Int, val h: Int, val px: IntArray, val t: Long)

/** Shared between CaptureService (writer) and DonatorService (reader). */
object CaptureHub {
    @Volatile var latest: RawFrame? = null
    @Volatile var active = false
    @Volatile var k = 2f          // real screen pixels per frame pixel
}
