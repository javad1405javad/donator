package com.autoclan.donator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.WindowManager
import java.nio.ByteOrder

/**
 * TURBO mode: continuous screen capture (MediaProjection) instead of one screenshot at a time.
 * The virtual display is created at HALF size, so frames are small and cheap.
 */
class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data: Intent? = intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try { startCapture(code, data) } catch (t: Throwable) { CaptureHub.active = false; stopSelf() }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("cap", "Fast capture", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "cap")
            .setContentTitle("Auto Clan Donator")
            .setContentText("TURBO capture is on")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        projection = p
        val th = HandlerThread("autoclan-cap"); th.start(); thread = th
        val h = Handler(th.looper)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { CaptureHub.active = false; stopSelf() }
        }, h)

        val b = (getSystemService(WINDOW_SERVICE) as WindowManager).maximumWindowMetrics.bounds
        val rw = maxOf(b.width(), b.height()); val rh = minOf(b.width(), b.height())   // the game is landscape
        val vw = rw / 2; val vh = rh / 2
        val dpi = resources.displayMetrics.densityDpi
        val r = ImageReader.newInstance(vw, vh, PixelFormat.RGBA_8888, 2)
        reader = r
        var last = 0L
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = System.currentTimeMillis()
                if (now - last >= 40) {          // at most ~25 frames per second
                    last = now
                    val plane = img.planes[0]
                    val ib = plane.buffer.order(ByteOrder.nativeOrder()).asIntBuffer()
                    val strideInts = plane.rowStride / 4
                    val w = img.width; val hh = img.height
                    val out = IntArray(w * hh)
                    for (y in 0 until hh) {
                        val src = y * strideInts; val dst = y * w
                        for (x in 0 until w) {
                            val v = ib.get(src + x)    // bytes R,G,B,A  ->  ARGB
                            out[dst + x] = (v and -16711936) or ((v and 255) shl 16) or ((v shr 16) and 255)
                        }
                    }
                    CaptureHub.latest = RawFrame(w, hh, out, now)
                }
            } catch (t: Throwable) {
            } finally { img.close() }
        }, h)
        vd = p.createVirtualDisplay("autoclan", vw, vh, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, h)
        CaptureHub.k = rw.toFloat() / vw
        CaptureHub.latest = null
        CaptureHub.active = true
    }

    override fun onDestroy() {
        CaptureHub.active = false; CaptureHub.latest = null
        try { vd?.release() } catch (t: Throwable) {}
        try { reader?.close() } catch (t: Throwable) {}
        try { projection?.stop() } catch (t: Throwable) {}
        thread?.quitSafely()
        super.onDestroy()
    }
}
