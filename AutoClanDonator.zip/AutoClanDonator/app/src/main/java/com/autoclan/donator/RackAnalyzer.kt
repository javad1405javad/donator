package com.autoclan.donator

import kotlin.math.abs

enum class RackState { EMPTY, HAS_IMAGES, UNKNOWN }

/** One request card found on the screen: pixel rows [top, bottom), the state of its troop strip and the score behind it. */
class CardResult(val top: Int, val bottom: Int, val state: RackState, val score: Float)

/**
 * Offline detector, no AI model and no network. It works on ONE screenshot (ARGB ints, width*height) of the
 * Clash of Clans clan chat and, for EVERY request card separately, decides:
 *   EMPTY       - the "requested troops" strip has no troop icons
 *   HAS_IMAGES  - one or more troop icons
 *   UNKNOWN     - in between, or the strip cannot be seen
 *
 * How it finds the cards (all sizes are relative to the screen height, so any phone works):
 *  1. The chat background is a flat color. Request cards are drawn 20% darker than it.
 *  2. A request card is told apart from join/leave messages by the black counter bars (0/45, 0/3 ...) near its bottom.
 *  3. The troop strip sits at a fixed distance above the card bottom. Troop icons are colorful, text is gray.
 */
object RackAnalyzer {
    const val EMPTY_BELOW = 0.03f     // colorful share below this  -> EMPTY
    const val IMAGES_FROM = 0.12f     // colorful share from this   -> HAS_IMAGES (in between -> UNKNOWN)

    fun analyze(px: IntArray, w: Int, h: Int): List<CardResult> {
        if (w < 16 || h < 64 || px.size < w * h) return emptyList()
        val s = h / 828f
        val panel = panelColor(px, w, h)
        val tr = panel[0] * 0.8f; val tg = panel[1] * 0.8f; val tb = panel[2] * 0.8f
        val tmax = maxOf(tr, maxOf(tg, tb))
        val tol = maxOf(2f, 0.08f * maxOf(panel[0], maxOf(panel[1], panel[2])))

        // which rows look like "inside a request card" (checked on a few columns near the right margin)
        val cols = floatArrayOf(0.605f, 0.615f, 0.625f, 0.633f).map { minOf(w - 1, (it * h).toInt()) }
        val mask = BooleanArray(h)
        for (y in 0 until h) {
            for (x in cols) {
                val p = px[y * w + x]
                val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
                if (abs(r - tr) <= tol && abs(g - tg) <= tol && abs(b - tb) <= tol) { mask[y] = true; break }
            }
        }
        // runs of such rows, then glue runs separated by tiny gaps (text pixels)
        val runs = ArrayList<IntArray>()
        var st = -1
        for (y in (0.05f * h).toInt() until (0.92f * h).toInt()) {
            if (mask[y] && st < 0) st = y
            if (!mask[y] && st >= 0) { runs.add(intArrayOf(st, y)); st = -1 }
        }
        val gap = (0.010f * h).toInt()
        val merged = ArrayList<IntArray>()
        for (r in runs) {
            if (merged.isNotEmpty() && r[0] - merged.last()[1] < gap) merged.last()[1] = r[1] else merged.add(r)
        }

        val out = ArrayList<CardResult>()
        for (m in merged) {
            val top = m[0]; val bottom = m[1]
            if (bottom - top < (0.12f * h).toInt()) continue            // too short: a chat message, not a request card

            // counters row: look for the black counter bars
            val cy = bottom - 51f * s
            val cy0 = maxOf(0, (cy - 0.012f * h).toInt()); val cy1 = minOf(h, (cy + 0.012f * h).toInt())
            val cx0 = (0.15f * h).toInt(); val cx1 = minOf(w, (0.50f * h).toInt())
            var dark = 0; var tot = 0
            for (y in cy0 until cy1) for (x in cx0 until cx1) {
                val p = px[y * w + x]
                val mx = maxOf((p shr 16) and 255, maxOf((p shr 8) and 255, p and 255))
                if (mx <= 0.55f * tmax) dark++
                tot++
            }
            if (tot == 0 || dark.toFloat() / tot < 0.04f) continue       // no counter bars: not a request card

            // the troop strip, clipped to the inside of the card
            val ry0 = maxOf((bottom - 172f * s).toInt(), top + (0.01f * h).toInt())
            val ry1 = minOf(h, (bottom - 97f * s).toInt())
            val rx0 = (0.135f * h).toInt(); val rx1 = minOf(w, (0.507f * h).toInt())
            if (ry1 <= ry0 || rx1 <= rx0) { out.add(CardResult(top, bottom, RackState.UNKNOWN, 0f)); continue }
            val floor = maxOf(12f, 0.9f * tmax)
            var colorful = 0; var n = 0
            for (y in ry0 until ry1) for (x in rx0 until rx1) {
                val p = px[y * w + x]
                val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
                val mx = maxOf(r, maxOf(g, b)); val mn = minOf(r, minOf(g, b))
                if (mx > floor && (mx - mn) * 100 > 35 * mx) colorful++
                n++
            }
            val score = colorful.toFloat() / n
            val state = if (score < EMPTY_BELOW) RackState.EMPTY else if (score >= IMAGES_FROM) RackState.HAS_IMAGES else RackState.UNKNOWN
            out.add(CardResult(top, bottom, state, score))
        }
        return out
    }

    /** Background color of the chat panel (most common color on the left margin). */
    private fun panelColor(px: IntArray, w: Int, h: Int): FloatArray {
        val x = (0.036f * h).toInt().coerceIn(0, w - 1)
        val n = 13
        val rs = IntArray(n); val gs = IntArray(n); val bs = IntArray(n); val keys = IntArray(n)
        for (i in 0 until n) {
            val y = (h * (0.2f + 0.6f * i / 12f)).toInt().coerceIn(0, h - 1)
            val p = px[y * w + x]
            rs[i] = (p shr 16) and 255; gs[i] = (p shr 8) and 255; bs[i] = p and 255
            keys[i] = ((rs[i] / 4) shl 16) or ((gs[i] / 4) shl 8) or (bs[i] / 4)
        }
        var best = keys[0]; var bestN = 0
        for (i in 0 until n) {
            var c = 0
            for (j in 0 until n) if (keys[j] == keys[i]) c++
            if (c > bestN) { bestN = c; best = keys[i] }
        }
        var sr = 0f; var sg = 0f; var sb = 0f; var k = 0
        for (i in 0 until n) if (keys[i] == best) { sr += rs[i]; sg += gs[i]; sb += bs[i]; k++ }
        return floatArrayOf(sr / k, sg / k, sb / k)
    }
}
