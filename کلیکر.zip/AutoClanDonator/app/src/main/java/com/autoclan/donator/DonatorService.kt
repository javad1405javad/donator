package com.autoclan.donator

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import kotlinx.coroutines.*
import kotlin.math.abs
import kotlin.random.Random

/**
 * All coordinates below are in a 1792x828 reference screen and are scaled by s = screenHeight / 828.
 * If taps land in the wrong place on your phone, tweak the CONFIG block.
 */
class DonatorService : AccessibilityService() {

    // ---- CONFIG ----
    private val COLS = floatArrayOf(611f, 698f, 786f, 873f, 960f, 1047f, 1135f) // card centers (x)
    private val ROW1 = 45f      // row1 center = panelAnchor + 45
    private val ROW2 = 155f     // row2 center = panelAnchor + 155
    private val SPELL = 312f    // spell row center = panelAnchor + 312
    private val BTN_X0 = 370f; private val BTN_X1 = 510f; private val BTN_CX = 440f
    private val FULL_GRID_MIN = 9      // >= this many colored troop cards => empty request
    private val SPELL_PROB = 0.5f      // chance to also give a spell on empty requests
    private val HOLD_EMPTY = 1200L     // ms hold on Super Barbarian
    private val HOLD_CARD = 700L       // ms hold per requested card
    private val SKIP_MS = 20000L
    // ----------------

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var job: Job? = null
    private var overlay: View? = null
    private val skip = ArrayList<Pair<Float, Long>>()

    override fun onServiceConnected() { addOverlay() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stop() }
    override fun onDestroy() { stop(); overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }; super.onDestroy() }

    private fun addOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        box.addView(Button(this).apply { text = "START"; setOnClickListener { start() } })
        box.addView(Button(this).apply { text = "STOP"; setOnClickListener { stop() } })
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; y = 40 }
        wm.addView(box, lp); overlay = box
    }

    private fun start() { if (job?.isActive == true) return; job = scope.launch { loop() } }
    private fun stop() { job?.cancel(); job = null }

    private suspend fun loop() {
        while (currentCoroutineContext().isActive) {
            val bmp = shot() ?: run { delay(80); null } ?: continue
            val s = bmp.height / 828f
            if (panelAnchor(bmp, s) != null) { press(1500f * s, 400f * s, 30); delay(150); continue } // stray popup: close
            val now = System.currentTimeMillis()
            val ys = greenButtons(bmp, s).filter { y -> skip.none { abs(it.first - y) < 30f * s && now - it.second < SKIP_MS } }
            if (ys.isEmpty()) { delay(40); continue }
            val y = ys.max()
            press(BTN_CX * s, y, 40)
            handlePopup(s)
            skip.add(y to System.currentTimeMillis())
            skip.removeAll { System.currentTimeMillis() - it.second > SKIP_MS }
            press(1500f * s, 400f * s, 30) // close popup
            delay(120)
        }
    }

    private suspend fun handlePopup(s: Float) {
        var bmp: Bitmap? = null; var fb: Int? = null
        val t0 = System.currentTimeMillis()
        while (System.currentTimeMillis() - t0 < 1500) {
            bmp = shot()
            fb = bmp?.let { panelAnchor(it, s) }
            if (fb != null) break
            delay(40)
        }
        if (bmp == null || fb == null) return
        val r1 = fb + ROW1 * s; val r2 = fb + ROW2 * s; val rs = fb + SPELL * s
        val troops = ArrayList<Pair<Float, Float>>(); val spells = ArrayList<Pair<Float, Float>>()
        for (c in COLS) if (colored(bmp, c * s, r1, (30 * s).toInt())) troops.add(c * s to r1)
        for (c in COLS) if (colored(bmp, c * s, r2, (30 * s).toInt())) troops.add(c * s to r2)
        for (c in COLS) if (colored(bmp, c * s, rs, (30 * s).toInt())) spells.add(c * s to rs)
        if (troops.size >= FULL_GRID_MIN) {
            press(COLS[0] * s, r1, HOLD_EMPTY)                       // Super Barbarian (top-left)
            if (spells.isNotEmpty() && Random.nextFloat() < SPELL_PROB) press(spells[0].first, spells[0].second, HOLD_CARD)
        } else {
            for (p in troops + spells) { press(p.first, p.second, HOLD_CARD); delay(Random.nextLong(30, 90)) }
        }
    }

    // ---------- vision ----------
    private fun colored(b: Bitmap, cx: Float, cy: Float, half: Int): Boolean {
        var c = 0; var t = 0
        var y = (cy - half).toInt().coerceAtLeast(0)
        while (y < (cy + half).toInt().coerceAtMost(b.height - 1)) {
            var x = (cx - half).toInt().coerceAtLeast(0)
            while (x < (cx + half).toInt().coerceAtMost(b.width - 1)) {
                val p = b.getPixel(x, y)
                val mx = maxOf(Color.red(p), Color.green(p), Color.blue(p)); val mn = minOf(Color.red(p), Color.green(p), Color.blue(p))
                if (mx > 76 && (mx - mn) > 0.25f * mx) c++
                t++; x += 3
            }
            y += 3
        }
        return t > 0 && c.toFloat() / t > 0.12f
    }

    /** First y of the beige popup panel at the left padding column; null if no popup is open. */
    private fun panelAnchor(b: Bitmap, s: Float): Int? {
        val x = (566 * s).toInt(); val col = IntArray(b.height)
        b.getPixels(col, 0, 1, x, 0, 1, b.height)
        var first = -1; var n = 0
        for (y in col.indices) {
            val p = col[y]
            if (abs(Color.red(p) - 216) < 10 && abs(Color.green(p) - 215) < 10 && abs(Color.blue(p) - 206) < 10) { if (first < 0) first = y; n++ }
        }
        return if (n > 300 * s) first else null
    }

    /** Centers (y) of green "donate" buttons in the chat column. */
    private fun greenButtons(b: Bitmap, s: Float): List<Float> {
        val out = ArrayList<Float>(); var start = -1
        val yMax = (b.height * 0.88f).toInt()
        var y = 0
        while (y <= yMax) {
            var cnt = 0; var x = (BTN_X0 * s).toInt()
            while (x < (BTN_X1 * s).toInt()) {
                val p = b.getPixel(x, y)
                val r = Color.red(p); val g = Color.green(p); val bl = Color.blue(p)
                val mx = maxOf(r, g, bl); val d = mx - minOf(r, g, bl)
                if (mx == g && d > 0 && mx >= 140 && d.toFloat() / mx > 0.4f) {
                    val h = 60f * (bl - r).toFloat() / d + 120f
                    if (h in 70f..110f) cnt++
                }
                x += 2
            }
            val on = cnt >= 20 * s
            if (on && start < 0) start = y
            if (!on && start >= 0) { if (y - start > 25 * s) out.add((start + y) / 2f); start = -1 }
            y += 2
        }
        return out
    }

    // ---------- device ----------
    private suspend fun shot(): Bitmap? = suspendCancellableCoroutine { c ->
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close(); if (c.isActive) c.resume(bmp) { }
            }
            override fun onFailure(code: Int) { if (c.isActive) c.resume(null) { } }
        })
    }

    private suspend fun press(x: Float, y: Float, ms: Long) = suspendCancellableCoroutine<Unit> { c ->
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, ms)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (c.isActive) c.resume(Unit) { } }
            override fun onCancelled(d: GestureDescription?) { if (c.isActive) c.resume(Unit) { } }
        }, null)
        if (!ok && c.isActive) c.resume(Unit) { }
    }
}
